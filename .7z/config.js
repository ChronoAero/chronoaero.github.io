"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var config = {
    serverUrl: "https://chronosrv.glitch.me/"
};
exports.default = config;
